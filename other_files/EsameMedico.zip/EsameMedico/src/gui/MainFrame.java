/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import java.util.List;

import EsameMedico.Clinica;
import EsameMedico.Ecocardiogramma;
import EsameMedico.EsameMedico;
import EsameMedico.Radiografia;
import exception.DataNonValidaException;
import utils.ClinicaSerializator;

/**
 *
 * @author fabiano
 */
public class MainFrame extends JFrame {
	private Clinica clinica;
	private JPanel radiografiaPanel;
	private JPanel ecocardiogrammaPanel;
	int screenSizeWidth;
	int screenSizeHeight;
	Font titleFont;
	JComboBox esameCombo;
	JPanel baseInfoEsamePanel;
	JTextField nomeMedicoField;
	JTextArea refertoTextArea;
	JTextField oggettoField;
	JComboBox<String> impegnativaCombo;
	JComboBox<String> ecoTipoCombo;
	JTextField etàField;
	List<EsameMedico> esami;
	JPanel datePanel;
	JTextField giorno;
	JTextField mese;
	JTextField anno;
	
	public MainFrame() throws ClassNotFoundException, IOException {
		super();
		clinica = (Clinica) ClinicaSerializator.deserialize();

		screenSizeWidth = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		screenSizeHeight = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();

		//setBounds((screenSizeWidth - 950) / 2, (screenSizeHeight - 700) / 2, 950, 700);

		createDatePanel();
		titleFont = new Font("Arial",Font.BOLD,25);
		if (clinica !=  null) {
			esami = clinica.getEsami();
			setContentPane(createMainPanel());
		}
		else {
			setContentPane(createRegistrationPanel());
		}
	}

	public JPanel createRegistrationPanel() {
		setBounds((screenSizeWidth - 350) / 2, (screenSizeHeight - 200) / 2, 350, 200);
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		JLabel title = new JLabel("Crea Nuova Clinica", JLabel.CENTER);
		title.setFont(titleFont);
		panel.add(title, BorderLayout.NORTH);
		
		JPanel info = new JPanel();
		info.add(new JLabel("Nome:"));
		JTextField nameField = new JTextField(20);
		info.add(nameField);
		info.add(new JLabel("Indirizzo:"));
		JTextField indirizzoField = new JTextField(20);
		info.add(indirizzoField);
		info.setBorder(new EmptyBorder(20, 0, 0, 0));
		panel.add(info, BorderLayout.CENTER);
		
		
		JButton confirmButton = new JButton("Conferma");
		confirmButton.setBackground(Color.green);
		confirmButton.setOpaque(true);
		confirmButton.setBorderPainted(false);
		panel.add(confirmButton, BorderLayout.SOUTH);
		confirmButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				clinica = new Clinica(nameField.getText(), indirizzoField.getText());
				esami = clinica.getEsami();
				ClinicaSerializator.serialize(clinica);
				setContentPane(createMainPanel());
				revalidate();				
			}
		});
		return panel;
	}
	
	public JPanel createMainPanel() {

		setBounds((screenSizeWidth - 800) / 2, (screenSizeHeight - 600) / 2, 800, 600);
		JPanel mainPanel = new JPanel();
		mainPanel.setOpaque(false);

		
		mainPanel.setLayout(new GridLayout(2, 1));
		JPanel panel = new JPanel();
		// panel.setOpaque(false);
		panel.setLayout(new BorderLayout());
		JLabel nomeClinica = new JLabel(clinica.getNome()+" ("+clinica.getIndirizzo()+")", JLabel.CENTER);
		nomeClinica.setFont(titleFont);
		nomeClinica.setForeground(Color.white);
		panel.add(nomeClinica, BorderLayout.NORTH);
		JLabel saldo = new JLabel(clinica.getCosto() + "€");
		saldo.setForeground(Color.white);
		saldo.setFont(new Font("Arial", Font.PLAIN, 80));
		panel.add(saldo, BorderLayout.EAST);
		panel.setBackground(Color.blue);
		JPanel listaEsami = new JPanel();
		listaEsami.setBackground(Color.blue);
		listaEsami.setOpaque(false);

		for (EsameMedico e : esami) {
			JLabel lab = new JLabel(e.toGUIString(),JLabel.LEFT);
			lab.setForeground(Color.white);
			listaEsami.add(lab);
		}
		panel.add(listaEsami,BorderLayout.CENTER);
		mainPanel.add(panel);
		
		JButton button1 = new JButton("Add Esame");
		panel = new JPanel();
		panel.add(button1);
		button1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setContentPane(createAddEsamePanel());
				revalidate();
			}
		});
		JButton button2 = new JButton("Ricerca per data");
		button2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				 int input = JOptionPane.showOptionDialog(null,datePanel,"Insert Date",JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE,null,null,null);

				 if(input == JOptionPane.OK_OPTION)
				 {
					 GregorianCalendar date = new GregorianCalendar(Integer.parseInt(anno.getText()),Integer.parseInt(mese.getText())-1,Integer.parseInt(giorno.getText()));
					 esami = clinica.getEsamiPerData(date);
				     setContentPane(createMainPanel());
				     revalidate();
				 }
			}
		});
		panel.add(button2);
		

		JButton button3 = new JButton("Ricerca per medico");
		button3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JPanel panel = new JPanel();
				 panel.add(new JLabel("Nome Medico"));
				 JTextField nomeMedico = new JTextField(20);
				 panel.add(nomeMedico);
				 panel.setBorder(new EmptyBorder(20,0,0,0));
				 int input = JOptionPane.showOptionDialog(null,panel,"Insert Date",JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE,null,null,null);

				 if(input == JOptionPane.OK_OPTION)
				 {
					 esami = clinica.getEsamiPerNome(nomeMedico.getText());
				     setContentPane(createMainPanel());
				     revalidate();
				 }
			}
		});
		panel.add(button3);

		JButton button4 = new JButton("Save");
		button4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ClinicaSerializator.serialize(clinica);
				JOptionPane.showMessageDialog(mainPanel, "Saved!");
			}
		});
		panel.add(button4);
		mainPanel.add(panel);
		return mainPanel;
	}
	
	public JPanel createAddEsamePanel() {
		JPanel addEsamePanel = new JPanel();
		addEsamePanel.setLayout(new BorderLayout());
		JLabel title = new JLabel("Aggiungi Nuovo Esame", JLabel.CENTER);
		title.setFont(titleFont);
		addEsamePanel.add(title, BorderLayout.NORTH);
		JPanel centerPanel = new JPanel();
		createEsameCombo();
		centerPanel.add(new JLabel("Seleziona Tipologia:"));
		centerPanel.add(esameCombo);
		createBaseInfoEsamePanel();
		centerPanel.add(baseInfoEsamePanel);
		createRadiografiaPanel();
		centerPanel.add(radiografiaPanel);
		createEcocardiogrammaPanel();
		ecocardiogrammaPanel.setVisible(false);
		centerPanel.add(ecocardiogrammaPanel);
		GregorianCalendar actualDate = new GregorianCalendar();
		giorno.setText(""+actualDate.get(Calendar.DATE));
		mese.setText(""+(actualDate.get(Calendar.MONTH)+1));
		anno.setText(""+actualDate.get(Calendar.YEAR));
		centerPanel.add(datePanel);
		centerPanel.setBorder(new EmptyBorder(100,0,0,0));
		addEsamePanel.add(centerPanel,BorderLayout.CENTER);
		JPanel southPanel = new JPanel();
		JButton backButton = new JButton("Back");
		backButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setContentPane(createMainPanel());
				revalidate();
			}
		});
		southPanel.add(backButton);
		JButton addEsameButton = new JButton("Effettua Esame");
		addEsameButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String tipologia = esameCombo.getSelectedItem().toString();
				String nomeMedico = nomeMedicoField.getText();
				String referto = refertoTextArea.getText();
				EsameMedico esameMedico = null;
				boolean pass = true;
				if (tipologia.toLowerCase().equals("radiografia")) {
					String oggetto = oggettoField.getText();
					boolean impegnativa = impegnativaCombo.getSelectedItem().toString().equals("SI")? true:false;
					esameMedico = new Radiografia(nomeMedico,oggetto,impegnativa);
				}
				else if (tipologia.toLowerCase().equals("ecocardiogramma")) {
					String ecoTipo = ecoTipoCombo.getSelectedItem().toString();
					int età = Integer.parseInt(etàField.getText());
					esameMedico = new Ecocardiogramma(nomeMedico,ecoTipo,età);
				}
				try {
					esameMedico.effettuaEsame(referto,new GregorianCalendar(Integer.parseInt(anno.getText()),Integer.parseInt(mese.getText())-1,Integer.parseInt(giorno.getText())));
					clinica.addEsame(esameMedico);
				}
				catch(DataNonValidaException dnve) {
					JOptionPane.showMessageDialog(addEsamePanel, dnve.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
				setContentPane(createMainPanel());
				revalidate();
			}
		});
		southPanel.add(addEsameButton);
		addEsamePanel.add(southPanel,BorderLayout.SOUTH);
		return addEsamePanel;
	}
	
	public void createBaseInfoEsamePanel() {
		baseInfoEsamePanel = new JPanel();
		baseInfoEsamePanel.add(new JLabel("Nome Medico:"));
		nomeMedicoField = new JTextField(20);
		baseInfoEsamePanel.add(nomeMedicoField);
		baseInfoEsamePanel.add(new JLabel("Referto:"));
		refertoTextArea = new JTextArea(10,30);
		baseInfoEsamePanel.add(refertoTextArea);
	}

	public void createRadiografiaPanel() {
		radiografiaPanel = new JPanel();
		radiografiaPanel.add(new JLabel("Nome Oggetto:"));
		oggettoField = new JTextField(20);
		radiografiaPanel.add(oggettoField);
		radiografiaPanel.add(new JLabel("Con Impegnativa:"));
		impegnativaCombo = new JComboBox<String>();
		impegnativaCombo.addItem("SI");
		impegnativaCombo.addItem("NO");
		radiografiaPanel.add(impegnativaCombo);
	}
	

	public void createEcocardiogrammaPanel() {
		ecocardiogrammaPanel = new JPanel();
		ecocardiogrammaPanel.add(new JLabel("Tipologia:"));
		ecoTipoCombo = new JComboBox<String>();
		ecoTipoCombo.addItem("Con Contrasto");
		ecoTipoCombo.addItem("Da Sforzo");
		ecoTipoCombo.addItem("ecc...");
		ecoTipoCombo.addItem("Altro");
		ecocardiogrammaPanel.add(ecoTipoCombo);
		ecocardiogrammaPanel.add(new JLabel("Età paziente:"));
		etàField = new JTextField(20);
		ecocardiogrammaPanel.add(etàField);
	}
	
	public void createEsameCombo() {
		esameCombo = new JComboBox<String>();
		esameCombo.addItem("Radiografia");
		esameCombo.addItem("Ecocardiogramma");
		esameCombo.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(esameCombo.getSelectedItem().toString().toLowerCase().equals("radiografia")) {
					radiografiaPanel.setVisible(true);
					ecocardiogrammaPanel.setVisible(false);
					revalidate();
				}
				else if(esameCombo.getSelectedItem().toString().toLowerCase().equals("ecocardiogramma")) {
					ecocardiogrammaPanel.setVisible(true);
					radiografiaPanel.setVisible(false);
					revalidate();
				}
			}
		});
	}
	
	public void createDatePanel() {
		 datePanel = new JPanel();
		 datePanel.add(new JLabel("Giorno"));
		 giorno = new JTextField(2);
		 datePanel.add(giorno);
		 datePanel.add(new JLabel("Mese"));
		 mese = new JTextField(2);
		 datePanel.add(mese);
		 datePanel.add(new JLabel("Anno"));
		 anno = new JTextField(4);
		 datePanel.add(anno);
		 datePanel.setBorder(new EmptyBorder(20,0,0,0));
	}
}
