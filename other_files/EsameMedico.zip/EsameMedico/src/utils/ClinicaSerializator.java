package utils;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import EsameMedico.Clinica;


/**
 *
 * @author fabiano
 */
public class ClinicaSerializator{

    private static final String FILE_PATH = "clinica.txt";
    
    public static void serialize(Clinica c) {
        try {
         FileOutputStream fileOut = new FileOutputStream(FILE_PATH);
         ObjectOutputStream out = new ObjectOutputStream(fileOut);
         out.writeObject(c);
         out.close();
         fileOut.close();
         System.out.println("Serialized data is saved in "+ FILE_PATH);
      } catch (IOException i) {
         i.printStackTrace();
      }
    }

    public static Clinica deserialize() {
        Clinica c = null;
        try {
         FileInputStream fileIn = new FileInputStream(FILE_PATH);
         ObjectInputStream in = new ObjectInputStream(fileIn);
         c = (Clinica) in.readObject();
         in.close();
         fileIn.close();
         System.out.println("Restored data from "+ FILE_PATH);
      } catch (Exception i) {
            System.out.println(i.getMessage());
      }
        return c;
    }
    
}
