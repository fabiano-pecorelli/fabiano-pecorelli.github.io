/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EsameMedico;

import java.util.Calendar;

/**
 *
 * @author fabiano
 */
public class Ecocardiogramma extends EsameMedico{
    private String tipologia;
    private int etàPaziente;

    public Ecocardiogramma(String nomeMedico, String tipologia, int etàPaziente) {
        super(nomeMedico);
        this.tipologia = tipologia;
        this.etàPaziente = etàPaziente;
    }

    
    @Override
    public double getCosto() {
        double toReturn = (tipologia.toLowerCase().equals("con contrasto"))? 45:30;
        return (etàPaziente > 65)? toReturn*0.8:toReturn;
    }

    public String getTipologia() {
        return tipologia;
    }

    public void setTipologia(String tipologia) {
        this.tipologia = tipologia;
    }

    public int getEtàPaziente() {
        return etàPaziente;
    }

    public void setEtàPaziente(int etàPaziente) {
        this.etàPaziente = etàPaziente;
    }


    @Override
	public String toGUIString() {
        return "Ecocardiogramma "+tipologia+" effettuato il "+getData().get(Calendar.DATE)+"/"+(getData().get(Calendar.MONTH)+1)+"/"+getData().get(Calendar.YEAR)+" dal medico "+getNomeMedico();	    
	}
    
}
