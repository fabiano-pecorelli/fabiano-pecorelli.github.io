/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EsameMedico;

import java.text.ParseException;
import java.util.GregorianCalendar;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author fably
 */
public class Main {
    
    public static void main(String[] args) throws ParseException {
       /* EsameMedico em = new EsameMedico("Fabiano");
        Scanner in = new Scanner(System.in);
        
        boolean flag = true;
        while(flag){
            try {
                System.out.println("Inserire data");
                String d = in.nextLine();
                String[] splitted = d.split("-");
                int year = Integer.parseInt(splitted[2]);
                int month = Integer.parseInt(splitted[1]);
                int day = Integer.parseInt(splitted[0]);
                GregorianCalendar date = new GregorianCalendar(year,month-1,day);
                em.effettuaEsame("Referto", date);
                flag = false;
            } catch (DataNonValidaException ex) {
                System.out.println(ex.getMessage());
            }
        }*/
       double a = 3.7;
       int x = (int) a;
       System.out.println(x);
    }
    
}
