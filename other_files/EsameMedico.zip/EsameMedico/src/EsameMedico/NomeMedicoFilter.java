/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EsameMedico;

/**
 *
 * @author fably
 */
public class NomeMedicoFilter implements Filter{

    @Override
    public boolean accept(Object obj, Object filter) {
        EsameMedico e = (EsameMedico) obj;
        String f = (String) filter;
        return e.getNomeMedico().equals(f);
    }
    
}
