/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EsameMedico;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author fably
 */
public class DataFilter implements Filter{

    @Override
    public boolean accept(Object obj, Object filter) {
        EsameMedico e = (EsameMedico) obj;
        GregorianCalendar f = (GregorianCalendar) filter;
        return e.getData().get(Calendar.DATE) == f.get(Calendar.DATE) && e.getData().get(Calendar.MONTH) == f.get(Calendar.MONTH) && e.getData().get(Calendar.YEAR) == f.get(Calendar.YEAR);
    }
    
}
