/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EsameMedico;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.GregorianCalendar;

import exception.NoEsamiPerDataException;
import exception.NoEsamiPerMedicoException;

/**
 *
 * @author fabiano
 */
public class Clinica implements Serializable{

	private String nome;
	private String indirizzo;
    private ArrayList<EsameMedico> esami;

    public Clinica(String nome, String indirizzo) {
    	this.nome = nome;
    	this.indirizzo = indirizzo;
        this.esami = new ArrayList<EsameMedico>();
    }

    public void addEsame(EsameMedico e) {
        for (int i = 0; i < esami.size(); i++) {
            if (e.compareTo(esami.get(i)) >= 0) {
                esami.add(i, e);
                return;
            }
        }
        esami.add(e);
    }
    
    public ArrayList<EsameMedico> getEsamiPerData(GregorianCalendar data) throws NoEsamiPerDataException{
        ArrayList<EsameMedico> toReturn = new ArrayList<EsameMedico>();
        Filter f = new DataFilter();
        for (EsameMedico e : esami){
            if (f.accept(e, data))
                toReturn.add(e);
        }
        if (toReturn.isEmpty()) {
        	throw new NoEsamiPerDataException("Nessun esame trovato per la data selezionata");
        }
        return toReturn;
    }
    
    public ArrayList<EsameMedico> getEsamiPerNome(String nome) throws NoEsamiPerMedicoException{
        ArrayList<EsameMedico> toReturn = new ArrayList<EsameMedico>();
        Filter f = new NomeMedicoFilter();
        for (EsameMedico e : esami){
            if (f.accept(e, nome))
                toReturn.add(e);
        }
        if (toReturn.isEmpty()) {
        	throw new NoEsamiPerMedicoException("Nessun esame trovato per il medico selezionato");
        }
        return toReturn;
    }
    
    public double getCosto(){
        double costo = 0;
        for(EsameMedico e : esami){
            costo += e.getCosto();
        }
        return costo;
    }

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getIndirizzo() {
		return indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	public ArrayList<EsameMedico> getEsami() {
		return esami;
	}

	public void setEsami(ArrayList<EsameMedico> esami) {
		this.esami = esami;
	}
    
    
}
