/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EsameMedico;

import java.util.Calendar;

/**
 *
 * @author fabiano
 */
public class Radiografia extends EsameMedico{
    private String oggettoRadiografato;
    private boolean impegnativa;

    public Radiografia(String nomeMedico, String oggettoRadiografato, boolean impegnativa) {
        super(nomeMedico);
        this.oggettoRadiografato = oggettoRadiografato;
        this.impegnativa = impegnativa;
    }
    
    @Override
    public double getCosto(){
        if (impegnativa)
            return 13;
        else return 20;
    }
    
    public String getOggettoRadiografato() {
        return oggettoRadiografato;
    }

    public void setOggettoRadiografato(String oggettoRadiografato) {
        this.oggettoRadiografato = oggettoRadiografato;
    }

    public boolean isImpegnativa() {
        return impegnativa;
    }

    public void setImpegnativa(boolean impegnativa) {
        this.impegnativa = impegnativa;
    }

	@Override
	public String toGUIString() {
		String imp = impegnativa? "Con":"Senza";
        return "Radiografia al "+oggettoRadiografato+" effettuata il "+getData().get(Calendar.DATE)+"/"+(getData().get(Calendar.MONTH)+1)+"/"+getData().get(Calendar.YEAR)+" dal medico "+getNomeMedico()+" "+imp+" impegnativa";		    
	}
    
    
  
    
}
