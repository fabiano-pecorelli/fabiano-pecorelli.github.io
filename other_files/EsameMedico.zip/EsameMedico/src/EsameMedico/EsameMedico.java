package EsameMedico;

import java.io.Serializable;
import java.util.GregorianCalendar;
import exception.DataNonValidaException;

public abstract class EsameMedico implements Comparable, Serializable{

    private String nomeMedico;
    private String referto;
    private GregorianCalendar data;
    private double costo;

    public EsameMedico(String nomeMedico) {
        this.nomeMedico = nomeMedico;
    }

    public void effettuaEsame(String referto, GregorianCalendar data) throws DataNonValidaException{
        if (data.compareTo(new GregorianCalendar()) > 0)
            throw new DataNonValidaException("La data inserita è successiva alla data attuale");
        this.referto = referto;
        this.data = data;
    }

    @Override
    public String toString() {
        return "EsameMedico{" + "nomeMedico=" + nomeMedico + ", referto=" + referto + ", data=" + data + '}';
    }

   
    public abstract String toGUIString();
    
    public String getNomeMedico() {
        return nomeMedico;
    }

    public void setNomeMedico(String nomeMedico) {
        this.nomeMedico = nomeMedico;
    }

    public String getReferto() {
        return referto;
    }

    public void setReferto(String referto) {
        this.referto = referto;
    }

    public GregorianCalendar getData() {
        return data;
    }

    public void setData(GregorianCalendar data) {
        this.data = data;
    }

    public abstract double getCosto();

    @Override
    public int compareTo(Object obj) {
        EsameMedico e2 = (EsameMedico) obj;
        return data.compareTo(e2.getData());
    }
}
