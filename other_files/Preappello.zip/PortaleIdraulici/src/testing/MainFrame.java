package testing;

import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import exceptions.GiudizioNonValidoException;
import exceptions.IdraulicoNonAbilitatoException;
import portaleidraulici.Idraulico;
import portaleidraulici.PortaleIdraulici;
import portaleidraulici.TecnicoCaldaia;
import utils.Sorter;


public class MainFrame extends JFrame{

	private PortaleIdraulici portaleIdraulici;
	private String marca;
	
	public MainFrame(PortaleIdraulici portaleIdraulici) throws ClassNotFoundException, IOException {
		super();
		this.portaleIdraulici = portaleIdraulici;
		
		int screenSizeWidth = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		int screenSizeHeight = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();

		setBounds((screenSizeWidth - 950) / 2, (screenSizeHeight - 700) / 2, 950, 700);

		setContentPane(createPanel1());
	}
	
	private JPanel createPanel1() {
		JPanel panel1 = new JPanel();
		panel1.add(new JLabel("Inserisci Marca"));
		JComboBox combo = new JComboBox();
		List<String> marche = getAllMarche();
		for (String m : marche) {
			combo.addItem(m);
		}
		panel1.add(combo);
		JButton cerca = new JButton("Cerca");
		cerca.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				marca = combo.getSelectedItem().toString();
				List<TecnicoCaldaia> idrauliciPerMarca = portaleIdraulici.getIdrauliciPerMarca(marca);
				Sorter.sort(idrauliciPerMarca);
				setContentPane(createPanel2(idrauliciPerMarca));
				revalidate();
			}			
		});
		panel1.add(cerca);
		return panel1;
	}
	
	private JPanel createPanel2(List<TecnicoCaldaia> idraulici) {
		JPanel panel2 = new JPanel();
		panel2.setLayout(new GridLayout(idraulici.size()+1,1));
		panel2.add(createIntestazionePanel());
		for (TecnicoCaldaia t : idraulici) {
			panel2.add(createInfoPanel(t,true));
		}
		return panel2;
	}

	private JPanel createIntestazionePanel() {
		JPanel p = new JPanel();
		p.add(new JLabel("Cognome,Nome"));
		p.add(new JLabel("Numero Interventi"));
		p.add(new JLabel("Giudizio Medio"));
		p.add(new JLabel(""));
		return p;
	}

	private JPanel createInfoPanel(TecnicoCaldaia t, boolean button) {
		JPanel p = new JPanel();
		p.add(new JLabel(t.getCognome()+","+t.getNome()));
		p.add(new JLabel(t.getNumeroInterventi()+""));
		p.add(new JLabel(t.getGiudizioMedio()+""));

		if (button) {
			JButton valuta = new JButton("Valuta");
			valuta.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					setContentPane(createPanel3(t));
					revalidate();
				}
				
			});
			p.add(valuta);
		}
		else {
			p.add(new JLabel(""));
		}
		return p;
	}
	
	private JPanel createPanel3(TecnicoCaldaia t) {
		JPanel panel3 = new JPanel();
		panel3.setLayout(new GridLayout(2,1));
		panel3.add(createInfoPanel(t, false));
		JPanel voto = new JPanel();
		voto.add(new JLabel("Inserisci voto"));
		JComboBox combo = new JComboBox();
		combo.addItem(5);
		combo.addItem(4);
		combo.addItem(3);
		combo.addItem(2);
		combo.addItem(1);
		voto.add(combo);
		JButton salva = new JButton("Salva");
		salva.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int giudizio = (int) combo.getSelectedItem();
				try {
					portaleIdraulici.effettuaIntervento(t.getMatricola(), "", true, marca, giudizio);
				} catch (IdraulicoNonAbilitatoException | GiudizioNonValidoException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				setContentPane(createPanel1());
				revalidate();
			}
			
		});
		voto.add(salva);
		panel3.add(voto);
		return panel3;
	}
	
	private List<String> getAllMarche(){
		List<String> marche = new ArrayList<String>();		
		for (Idraulico i : portaleIdraulici.getIdraulici()) {
			if (i instanceof TecnicoCaldaia) {
				for (String marca : ((TecnicoCaldaia) i).getCaseCostruttrici()) {
					if (!marche.contains(marca)) {
						marche.add(marca);
					}
				}
			}
		}
		return marche;
	}
}
