package testing;

import java.io.IOException;

import javax.swing.JFrame;

import portaleidraulici.Idraulico;
import portaleidraulici.PortaleIdraulici;
import portaleidraulici.TecnicoCaldaia;

public class Collaudo {
	
	public static void main(String[] args) throws ClassNotFoundException, IOException {
		PortaleIdraulici portale = new PortaleIdraulici();
		
		portale.aggiungiIdraulico(new Idraulico(1,"Idraulico","Primo"));
		portale.aggiungiIdraulico(new Idraulico(2,"Idraulico","Secondo"));
		portale.aggiungiIdraulico(new Idraulico(3,"Idraulico","Terzo"));
		portale.aggiungiIdraulico(new Idraulico(4,"Idraulico","Quarto"));
		portale.aggiungiIdraulico(new Idraulico(5,"Idraulico","Quinto"));
		

		TecnicoCaldaia tecnico = new TecnicoCaldaia(6,"Tecnico","Primo");
		tecnico.aggiungiCasaCostruttrice("Ferroli");
		tecnico.aggiungiCasaCostruttrice("Bosch");
		portale.aggiungiIdraulico(tecnico);
		
		tecnico = new TecnicoCaldaia(7,"Tecnico","Secondo");
		tecnico.aggiungiCasaCostruttrice("Junkers");
		tecnico.aggiungiCasaCostruttrice("Bosch");
		portale.aggiungiIdraulico(tecnico);
		
		tecnico = new TecnicoCaldaia(8,"Tecnico","Terzo");
		tecnico.aggiungiCasaCostruttrice("Ferroli");
		tecnico.aggiungiCasaCostruttrice("Vaillant");
		portale.aggiungiIdraulico(tecnico);
		
		tecnico = new TecnicoCaldaia(9,"Tecnico","Quarto");
		tecnico.aggiungiCasaCostruttrice("Ferroli");
		tecnico.aggiungiCasaCostruttrice("Junkers");
		tecnico.aggiungiCasaCostruttrice("Vaillant");
		tecnico.aggiungiCasaCostruttrice("Bosch");
		portale.aggiungiIdraulico(tecnico);
		
		tecnico = new TecnicoCaldaia(10,"Tecnico","Quinto");
		tecnico.aggiungiCasaCostruttrice("Bosch");
		portale.aggiungiIdraulico(tecnico);
		
		MainFrame frame = new MainFrame(portale);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
}


}
