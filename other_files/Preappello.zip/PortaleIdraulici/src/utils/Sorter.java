package utils;

import java.util.ArrayList;
import java.util.List;

public class Sorter {

	public static void sort(List v) { 
		int k;
		int n = v.size();
		k = 0;
		while (k != n-1)  {
			int j = getGreatest(v, k);
	    	exchange(v, k, j);
	    	k++;
	    } 
	}
	
	public static int getGreatest(List  v,  int  k)  {
	//  funziona su qualunque implem. di Comparable
	   if  (v==null  ||  v.size()==k)
	       return  -1;
	   int i;
	   int small = k;
	   i  =  k+1;
	   while  (i != v.size())  {
	       Comparable current  = (Comparable)  v.get(i);
	       Comparable greatest  = (Comparable) v.get(small);
	       if  (current.compareTo(greatest) > 0)
	             small  =  i;
	       i++;
	}
	   return small;
	}
	
	public static void exchange(List  v,  int  k, int j)  {
		Object temp = v.get(j);
		v.set(j, v.get(k));
		v.set(k, temp);
	}

}
