/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.util.Calendar;
import java.util.GregorianCalendar;

import portaleidraulici.TecnicoCaldaia;

/**
 *
 * @author fably
 */
public class MarcaFilter implements Filter{

    @Override
    public boolean accept(Object obj, Object filter) {
        TecnicoCaldaia tc = (TecnicoCaldaia) obj;
        String f = (String) filter;
        return tc.getCaseCostruttrici().contains(f);
    }
    
}
