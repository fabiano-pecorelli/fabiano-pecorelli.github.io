package exceptions;


public class IdraulicoNonAbilitatoException extends Exception{

	public IdraulicoNonAbilitatoException() {
		super("Solo un tecnico caldaia può effettuare interventi su una caldaia");
	}
}
