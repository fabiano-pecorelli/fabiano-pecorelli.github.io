package exceptions;

public class CertificazioneMancanteException extends RuntimeException{

	public CertificazioneMancanteException() {
		super("Il tecnico non ha la certificazione per la marca di caldaie selezionata");
	}
}
