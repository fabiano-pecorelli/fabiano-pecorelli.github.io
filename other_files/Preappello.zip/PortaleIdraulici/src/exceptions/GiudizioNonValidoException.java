package exceptions;

public class GiudizioNonValidoException extends Exception{

	public GiudizioNonValidoException() {
		super("Il giudizio deve essere un intero compreso tra 1 e 5");
	}
}
