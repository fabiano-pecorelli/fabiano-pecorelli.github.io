package portaleidraulici;

import java.util.ArrayList;
import java.util.List;

import exceptions.GiudizioNonValidoException;
import exceptions.IdraulicoNonAbilitatoException;
import utils.Filter;
import utils.MarcaFilter;

public class PortaleIdraulici {

	private List<Idraulico> idraulici;
	
	
	public PortaleIdraulici() {
		idraulici = new ArrayList<Idraulico>();
	}
	
	public void aggiungiIdraulico(Idraulico idraulico) {
		if (!idraulici.contains(idraulico))
			idraulici.add(idraulico);
	}
	
	private Idraulico cercaIdraulico(int matricola) {
		for (Idraulico i : idraulici) {
			if (i.getMatricola() == matricola)
				return i;
		}
		return null;
	}
	
	public void effettuaIntervento(int matricola, String tipo, boolean caldaia, String marca, int giudizio) throws IdraulicoNonAbilitatoException, GiudizioNonValidoException{
		Idraulico idraulico = cercaIdraulico(matricola);
		if (caldaia)
			effettuaInterventoCaldaia(idraulico, marca, giudizio);
		else
			effettuaInterventoImpianto(idraulico, tipo);	
	}
	
	private void effettuaInterventoImpianto(Idraulico idraulico, String tipo) {
		idraulico.effettuaIntervento(tipo);
	}
	
	private void effettuaInterventoCaldaia(Idraulico idraulico, String marca, int giudizio) throws IdraulicoNonAbilitatoException, GiudizioNonValidoException {
		if (!(idraulico instanceof TecnicoCaldaia)) 
			throw new IdraulicoNonAbilitatoException();
		((TecnicoCaldaia) idraulico).effettuaIntervento(marca, giudizio);
	}
	
	public Idraulico getIdraulicoConPiuInterventi() {
		Idraulico max = idraulici.get(0);
		for (Idraulico i : idraulici) {
			if (i.getNumeroInterventi() > max.getNumeroInterventi())
				max = i;
		}
		return max;
	}
	
	public List<TecnicoCaldaia> getIdrauliciPerMarca(String marca){
		List<TecnicoCaldaia> toReturn = new ArrayList<TecnicoCaldaia>();
		Filter f = new MarcaFilter();
        for (Idraulico i : idraulici){
            if ((i instanceof TecnicoCaldaia) && f.accept(i, marca))
                toReturn.add((TecnicoCaldaia) i);
        }
        return toReturn;
	}

	public List<Idraulico> getIdraulici() {
		return idraulici;
	}

	public void setIdraulici(List<Idraulico> idraulici) {
		this.idraulici = idraulici;
	}
	
	
}
