package portaleidraulici;

import java.util.ArrayList;

import exceptions.CertificazioneMancanteException;
import exceptions.GiudizioNonValidoException;

public class TecnicoCaldaia extends Idraulico implements Comparable{

	
	private ArrayList<String> caseCostruttrici;
	private double giudizioMedio;
	
	public TecnicoCaldaia(int matricola, String cognome, String nome) {
		super(matricola, cognome, nome);
		caseCostruttrici = new ArrayList<String>();
		giudizioMedio = 0;
	}
	
	public void effettuaIntervento(String marcaCaldaia, int giudizio) throws GiudizioNonValidoException {
		if (!caseCostruttrici.contains(marcaCaldaia)) {
			throw new CertificazioneMancanteException();
		}
		if (giudizio < 1 || giudizio > 5)
			throw new GiudizioNonValidoException();
		
		if (giudizioMedio == 0)
			giudizioMedio = giudizio;
		else {
			double tot = (giudizioMedio * numeroInterventi) + giudizio;
			giudizioMedio = tot /(numeroInterventi + 1);
		}
		super.effettuaIntervento("Riparazione Caldaia");
	}
	
	public void aggiungiCasaCostruttrice(String casaCostruttrice) {
		if (!caseCostruttrici.contains(casaCostruttrice)) {
			caseCostruttrici.add(casaCostruttrice);
		}
	}

	public ArrayList<String> getCaseCostruttrici() {
		return caseCostruttrici;
	}

	public void setCaseCostruttrici(ArrayList<String> caseCostruttrici) {
		this.caseCostruttrici = caseCostruttrici;
	}

	public double getGiudizioMedio() {
		return giudizioMedio;
	}

	public void setGiudizioMedio(double giudizioMedio) {
		this.giudizioMedio = giudizioMedio;
	}

	@Override
	public int compareTo(Object o) {
		return Double.compare(this.getGiudizioMedio(), ((TecnicoCaldaia) o).getGiudizioMedio());
	}

}
