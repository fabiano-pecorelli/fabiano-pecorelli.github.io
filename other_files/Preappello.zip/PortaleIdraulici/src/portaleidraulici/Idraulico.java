package portaleidraulici;

import java.util.ArrayList;

public class Idraulico {

	int matricola;
	String cognome;
	String nome;
	ArrayList<String> tipiInterventi;
	int numeroInterventi;
	
	public Idraulico(int matricola, String cognome, String nome) {
		super();
		this.matricola = matricola;
		this.cognome = cognome;
		this.nome = nome;
		this.tipiInterventi = new ArrayList<String>();
		this.numeroInterventi = 0;
	}

	public void effettuaIntervento(String tipo) {
		numeroInterventi++;
		aggiungiTipoIntervento(tipo);
	}
	
	private void aggiungiTipoIntervento(String tipo) {
		if (!tipiInterventi.contains(tipo))
			tipiInterventi.add(tipo);
	}
	
	public int getMatricola() {
		return matricola;
	}

	public void setMatricola(int matricola) {
		this.matricola = matricola;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public ArrayList<String> getTipiInterventi() {
		return tipiInterventi;
	}

	public void setTipiInterventi(ArrayList<String> tipiInterventi) {
		this.tipiInterventi = tipiInterventi;
	}

	public int getNumeroInterventi() {
		return numeroInterventi;
	}

	public void setNumeroInterventi(int numeroInterventi) {
		this.numeroInterventi = numeroInterventi;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Idraulico other = (Idraulico) obj;
		if (matricola != other.matricola)
			return false;
		return true;
	}
	
	
	
}
