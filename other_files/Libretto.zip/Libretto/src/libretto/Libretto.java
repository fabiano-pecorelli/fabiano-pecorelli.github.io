package libretto;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import exception.CFUNonValidiException;
import exception.EsameGiàPresenteException;
import exception.VotoNonValidoException;

public class Libretto implements Serializable{

	private Studente studente;
	private List<Esame> esami;
	
	public Libretto(Studente studente) {
		super();
		this.studente = studente;
		esami = new ArrayList<Esame>();
	}

	public Studente getStudente() {
		return studente;
	}

	public void setStudente(Studente studente) {
		this.studente = studente;
	}

	public List<Esame> getEsami() {
		return esami;
	}

	public void addEsame(Esame e) throws VotoNonValidoException, EsameGiàPresenteException, CFUNonValidiException {
		if (e.getVoto() < 18 || e.getVoto() > 30)
			throw new VotoNonValidoException();
		if (esami.contains(e))
			throw new EsameGiàPresenteException();
		if (e.getCFU() < 0)
			throw new CFUNonValidiException();
		esami.add(e);
	}

	public double calcolaMedia() {
		double somma = 0;
		double nEsami = 0;
		for (Esame e : getEsami()) {
			nEsami++;
			somma+=e.getVoto();
		}
		return somma/nEsami;
	}
	
	public double calcolaMediaPonderata(){
		double somma = 0;
		double nEsami = 0;
		int totCFU = 0;
		for (Esame e : getEsami()) {
			nEsami++;
			somma+=e.getVoto()*e.getCFU();
			totCFU += e.getCFU();
		}
		return somma/totCFU;
	}
	
	public int dammiCFUConseguiti() {
		int CFU = 0;
		for (Esame e : esami) {
			CFU += e.getCFU(); 
		}
		return CFU;
	}
	
	public boolean esameSuperato(String nomeCorso) {
		boolean passed = false;
		for (Esame e : esami) {
			if (e.getCorso().getNomeCorso().equals(nomeCorso)) {
				passed = true;
				break;
			}
		}
		return passed;
	}
}
