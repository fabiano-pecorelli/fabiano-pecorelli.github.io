package libretto;
import java.io.Serializable;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Studente implements Serializable{

	private String nome;
	private String cognome;
	private int matricola;
	private GregorianCalendar dataNascita;
	private int annoIscrizione;
	
	
	
	public Studente(String nome, String cognome, int matricola, GregorianCalendar dataNascita, int annoIscrizione) {
		super();
		this.nome = nome;
		this.cognome = cognome;
		this.matricola = matricola;
		this.dataNascita = dataNascita;
		this.annoIscrizione = annoIscrizione;
	}
	
	

	public String getNome() {
		return nome;
	}



	public void setNome(String nome) {
		this.nome = nome;
	}



	public String getCognome() {
		return cognome;
	}



	public void setCognome(String cognome) {
		this.cognome = cognome;
	}



	public int getMatricola() {
		return matricola;
	}



	public void setMatricola(int matricola) {
		this.matricola = matricola;
	}



	public GregorianCalendar getDataNascita() {
		return dataNascita;
	}



	public void setDataNascita(GregorianCalendar dataNascita) {
		this.dataNascita = dataNascita;
	}



	public int getAnnoIscrizione() {
		return annoIscrizione;
	}



	public void setAnnoIscrizione(int annoIscrizione) {
		this.annoIscrizione = annoIscrizione;
	}



	public int dammiClasse(){
		return (matricola%3)+1;
	}
	
	public int dammiEtà() {
		return (new GregorianCalendar().get(Calendar.YEAR) - dataNascita.get(Calendar.YEAR));
	}
	public boolean  eFuoriCorso() {
		return (new GregorianCalendar().get(Calendar.YEAR) - annoIscrizione) > 3;
	}
	public boolean stessaClasse(Studente s2) {
		return dammiClasse() == s2.dammiClasse();
	}
}
