package libretto;

import java.io.Serializable;

public class Corso implements Serializable{

	private String nomeCorso;
	private String nomeDocente;
	
	public Corso(String nomeCorso, String nomeDocente) {
		super();
		this.nomeCorso = nomeCorso;
		this.nomeDocente = nomeDocente;
	}
	public String getNomeCorso() {
		return nomeCorso;
	}
	public void setNomeCorso(String nomeCorso) {
		this.nomeCorso = nomeCorso;
	}
	public String getNomeDocente() {
		return nomeDocente;
	}
	public void setNomeDocente(String nomeDocente) {
		this.nomeDocente = nomeDocente;
	}
	
	public boolean equals(Object anObject) {
		return nomeCorso.equals(((Corso)anObject).getNomeCorso());
	}
	
	
}
