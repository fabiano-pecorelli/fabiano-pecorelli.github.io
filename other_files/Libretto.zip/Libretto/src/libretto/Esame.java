package libretto;
import java.io.Serializable;

import exception.LodeNonConsentitaException;

public class Esame implements Serializable{

	private Corso corso;
	private int voto;
	private int CFU;
	private boolean lode;
	
	public Esame(Corso corso, int voto, int CFU) {
		super();
		this.corso = corso;
		this.voto = voto;
		this.CFU = CFU;
		lode = false;
	}

	public Corso getCorso() {
		return corso;
	}

	public void setCorso(Corso corso) {
		this.corso = corso;
	}

	public int getVoto() {
		return voto;
	}

	public void setVoto(int voto) {
		this.voto = voto;
	}
	
	public boolean isLode() {
		return lode;
	}

	public int getCFU() {
		return CFU;
	}

	public void setCFU(int cFU) {
		CFU = cFU;
	}

	
	
	public boolean equals(Object anObject) {
		return corso.equals(((Esame)anObject).getCorso());
	}

	public void assegnaLode() throws LodeNonConsentitaException {
		if (voto != 30) {
			throw new LodeNonConsentitaException();
		}
		lode = true;
	}
	
}
