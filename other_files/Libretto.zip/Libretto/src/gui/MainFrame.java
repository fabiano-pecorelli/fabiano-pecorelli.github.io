/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import exception.CFUNonValidiException;
import exception.EsameGiàPresenteException;
import exception.LodeNonConsentitaException;
import exception.VotoNonValidoException;

import java.util.List;

import libretto.Corso;
import libretto.Esame;
import libretto.Libretto;
import libretto.Studente;
import utils.LibrettoSerializator;

/**
 *
 * @author fabiano
 */
public class MainFrame extends JFrame {
	int screenSizeWidth;
	int screenSizeHeight;
	private Libretto libretto;
	JPanel datePanel;
	JTextField giorno;
	JTextField mese;
	JTextField anno;
	JTextField nomeCorsoField;
	JTextField nomeDocenteField;
	JTextField votoField;
	JTextField CFUField;
	Font titleFont;
	JCheckBox lodeCheckBox;
	
	public MainFrame() throws ClassNotFoundException, IOException {
		super();
		libretto = (Libretto) LibrettoSerializator.deserialize();

		screenSizeWidth = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		screenSizeHeight = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();

		//setBounds((screenSizeWidth - 950) / 2, (screenSizeHeight - 700) / 2, 950, 700);

		createDatePanel();
		titleFont = new Font("Arial",Font.BOLD,25);
		if (libretto !=  null) {
			setContentPane(createMainPanel());
		}
		else {
			setContentPane(createRegistrationPanel());
		}
	}

	public JPanel createRegistrationPanel() {
		setBounds((screenSizeWidth - 350) / 2, (screenSizeHeight - 400) / 2, 350, 400);
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		JLabel title = new JLabel("Crea Nuovo Libretto", JLabel.CENTER);
		title.setFont(titleFont);
		panel.add(title, BorderLayout.NORTH);
		
		JPanel info = new JPanel();
		info.add(new JLabel("Nome:"));
		JTextField nameField = new JTextField(20);
		info.add(nameField);
		info.add(new JLabel("Cognome:"));
		JTextField cognomeField = new JTextField(20);
		info.add(cognomeField);
		info.add(new JLabel("Matricola:"));
		JTextField matricolaField = new JTextField(20);
		info.add(matricolaField);
		info.add(new JLabel("Data di nascita:"));
		info.add(datePanel);
		info.add(new JLabel("Anno di iscrizione:"));
		JTextField annoIscrizioneField = new JTextField(4);
		info.add(annoIscrizioneField);
		info.setBorder(new EmptyBorder(20, 0, 0, 0));
		panel.add(info, BorderLayout.CENTER);
		
		
		JButton confirmButton = new JButton("Conferma");
		confirmButton.setBackground(Color.green);
		confirmButton.setOpaque(true);
		confirmButton.setBorderPainted(false);
		panel.add(confirmButton, BorderLayout.SOUTH);
		confirmButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				libretto = new Libretto(new Studente(nameField.getText(),cognomeField.getText(), Integer.parseInt(matricolaField.getText()),new GregorianCalendar(Integer.parseInt(anno.getText()),Integer.parseInt(mese.getText())-1,Integer.parseInt(giorno.getText())),Integer.parseInt(annoIscrizioneField.getText())));
				LibrettoSerializator.serialize(libretto);
				setContentPane(createMainPanel());
				revalidate();				
			}
		});
		return panel;
	}
	
	public JPanel createMainPanel() {

		setBounds((screenSizeWidth - 800) / 2, (screenSizeHeight - 600) / 2, 800, 600);
		JPanel mainPanel = new JPanel();
		mainPanel.setOpaque(false);

		
		mainPanel.setLayout(new GridLayout(2, 1));
		JPanel panel = new JPanel();
		// panel.setOpaque(false);
		panel.setLayout(new BorderLayout());
		JLabel nomeClinica = new JLabel("Libretto di "+libretto.getStudente().getNome()+" "+libretto.getStudente().getCognome(), JLabel.CENTER);
		nomeClinica.setFont(titleFont);
		nomeClinica.setForeground(Color.white);
		panel.add(nomeClinica, BorderLayout.NORTH);
		panel.setBackground(Color.blue);

		mainPanel.add(panel);
		
		JButton button1 = new JButton("Add Esame");
		panel = new JPanel();
		panel.add(button1);
		button1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setContentPane(createAddEsamePanel());
				revalidate();
			}
		});
		JButton button2 = new JButton("Calcola Media");
		button2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				 JOptionPane.showMessageDialog(null,libretto.calcolaMedia(),"Totale CFU conseguiti", JOptionPane.INFORMATION_MESSAGE);
			}
		});
		panel.add(button2);

		JButton button2a = new JButton("Calcola Media Ponderata");
		button2a.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				 JOptionPane.showMessageDialog(null,libretto.calcolaMediaPonderata(),"Totale CFU conseguiti", JOptionPane.INFORMATION_MESSAGE);
			}
		});
		panel.add(button2a);
		

		JButton button3 = new JButton("Calcola CFU");
		button3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				 JOptionPane.showMessageDialog(null,libretto.dammiCFUConseguiti(),"Totale CFU conseguiti", JOptionPane.INFORMATION_MESSAGE);

			}
		});
		panel.add(button3);

		JButton button4 = new JButton("Save");
		button4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				LibrettoSerializator.serialize(libretto);
				JOptionPane.showMessageDialog(mainPanel, "Saved!");
			}
		});
		panel.add(button4);
		mainPanel.add(panel);
		return mainPanel;
	}
	
	public JPanel createAddEsamePanel() {
		JPanel addEsamePanel = new JPanel();
		addEsamePanel.setLayout(new BorderLayout());
		JLabel title = new JLabel("Aggiungi Nuovo Esame", JLabel.CENTER);
		title.setFont(titleFont);
		addEsamePanel.add(title, BorderLayout.NORTH);
		JPanel centerPanel = new JPanel();
		JPanel corsoPanel = new JPanel();

		corsoPanel.add(new JLabel("Nome Corso"));
		nomeCorsoField = new JTextField(20);
		corsoPanel.add(nomeCorsoField);

		corsoPanel.add(new JLabel("Nome Docente"));
		nomeDocenteField = new JTextField(20);
		corsoPanel.add(nomeDocenteField);
		corsoPanel.setBorder(new EmptyBorder(0, 50, 0, 50));
		centerPanel.add(corsoPanel);
		centerPanel.add(new JLabel("CFU"));
		CFUField = new JTextField(2);
		centerPanel.add(CFUField);

		centerPanel.add(new JLabel("Voto"));
		votoField = new JTextField(2);
		centerPanel.add(votoField);

		centerPanel.add(new JLabel("Lode"));
		lodeCheckBox = new JCheckBox();
		centerPanel.add(lodeCheckBox);
		
		centerPanel.setBorder(new EmptyBorder(100,0,0,0));
		addEsamePanel.add(centerPanel,BorderLayout.CENTER);
		JPanel southPanel = new JPanel();
		JButton backButton = new JButton("Back");
		backButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setContentPane(createMainPanel());
				revalidate();
			}
		});
		southPanel.add(backButton);
		JButton addEsameButton = new JButton("Conferma");
		addEsameButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String nomeCorso = nomeCorsoField.getText();
				String nomeDocente = nomeDocenteField.getText();
				int voto = Integer.parseInt(votoField.getText());
				int CFU = Integer.parseInt(CFUField.getText());
				boolean lode = lodeCheckBox.isSelected();
				Corso corso = new Corso(nomeCorso,nomeDocente);
				Esame esame = new Esame(corso,voto,CFU);
				
				try {
					if (lode)
						esame.assegnaLode();
					libretto.addEsame(esame);
					setContentPane(createMainPanel());
					revalidate();
				} catch (LodeNonConsentitaException | VotoNonValidoException | EsameGiàPresenteException | CFUNonValidiException ex) {
					JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		southPanel.add(addEsameButton);
		addEsamePanel.add(southPanel,BorderLayout.SOUTH);
		return addEsamePanel;
	}
	
	public void createDatePanel() {
		 datePanel = new JPanel();
		 datePanel.add(new JLabel("Giorno"));
		 giorno = new JTextField(2);
		 datePanel.add(giorno);
		 datePanel.add(new JLabel("Mese"));
		 mese = new JTextField(2);
		 datePanel.add(mese);
		 datePanel.add(new JLabel("Anno"));
		 anno = new JTextField(4);
		 datePanel.add(anno);
		 datePanel.setBorder(new EmptyBorder(20,0,0,0));
	}
}
