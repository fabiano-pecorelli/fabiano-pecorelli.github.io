package utils;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import libretto.Libretto;
/**
 *
 * @author fabiano
 */
public class LibrettoSerializator{

    private static final String FILE_PATH = "libretto.txt";
    
    public static void serialize(Libretto l) {
        try {
         FileOutputStream fileOut = new FileOutputStream(FILE_PATH);
         ObjectOutputStream out = new ObjectOutputStream(fileOut);
         out.writeObject(l);
         out.close();
         fileOut.close();
         System.out.println("Serialized data is saved in "+ FILE_PATH);
      } catch (IOException i) {
         i.printStackTrace();
      }
    }

    public static Libretto deserialize() {
    	Libretto l = null;
        try {
         FileInputStream fileIn = new FileInputStream(FILE_PATH);
         ObjectInputStream in = new ObjectInputStream(fileIn);
         l = (Libretto) in.readObject();
         in.close();
         fileIn.close();
         System.out.println("Restored data from "+ FILE_PATH);
      } catch (Exception i) {
            System.out.println(i.getMessage());
      }
        return l;
    }
    
}
