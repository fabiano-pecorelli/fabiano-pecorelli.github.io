package exception;

public class CFUNonValidiException extends Exception{

	
	public CFUNonValidiException() {
		super("Il numero di CFU deve essere maggiore di 0");
	}
}
