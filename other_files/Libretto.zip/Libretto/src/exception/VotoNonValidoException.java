package exception;

public class VotoNonValidoException extends Exception{

	
	public VotoNonValidoException() {
		super("Il voto deve essere compreso tra 18 e 30");
	}
}
