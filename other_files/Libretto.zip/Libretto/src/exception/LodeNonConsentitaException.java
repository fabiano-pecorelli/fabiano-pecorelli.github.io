package exception;

public class LodeNonConsentitaException extends Exception{

	
	public LodeNonConsentitaException() {
		super("Non è possibile assegnare la lode se il voto è diverso da 30");
	}
}
