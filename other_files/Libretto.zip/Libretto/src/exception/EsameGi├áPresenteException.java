package exception;

public class EsameGiàPresenteException extends Exception{

	
	public EsameGiàPresenteException() {
		super("Non è possibile aggiungere più esami per lo stesso corso");
	}
}
