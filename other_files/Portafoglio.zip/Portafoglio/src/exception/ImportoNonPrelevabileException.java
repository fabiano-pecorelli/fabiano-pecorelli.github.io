package exception;

public class ImportoNonPrelevabileException extends Exception{

	public ImportoNonPrelevabileException() {
		super("Imorto inserito magiore del saldo attuale");
	}
}
