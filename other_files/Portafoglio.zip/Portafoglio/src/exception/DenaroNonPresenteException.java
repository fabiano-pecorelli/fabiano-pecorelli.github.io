package exception;

public class DenaroNonPresenteException extends Exception{

	public DenaroNonPresenteException() {
		super("Denaro non presente!");
	}
}
