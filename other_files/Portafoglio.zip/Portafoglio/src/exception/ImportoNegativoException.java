package exception;

public class ImportoNegativoException extends Exception{

	public ImportoNegativoException() {
		super("Imorto inserito non valido");
	}
}
