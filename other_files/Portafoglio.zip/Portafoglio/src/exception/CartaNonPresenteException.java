package exception;

public class CartaNonPresenteException extends Exception{

	public CartaNonPresenteException() {
		super("Carta non presente!");
	}
}
