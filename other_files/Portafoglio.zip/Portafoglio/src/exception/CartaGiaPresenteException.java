package exception;

public class CartaGiaPresenteException extends Exception{

	public CartaGiaPresenteException() {
		super("Carta già presente!");
	}
}
