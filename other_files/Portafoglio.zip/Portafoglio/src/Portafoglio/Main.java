/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Portafoglio;

import exception.CartaGiaPresenteException;
import exception.ImportoNegativoException;

/**
 *
 * @author fabiano
 */
public class Main {
    
     public static void main(String[] args) throws ImportoNegativoException, CartaGiaPresenteException{
         Portafoglio portafoglio = null;
         if (portafoglio == null)
                portafoglio = new Portafoglio();
         Card cf = new Card("Codice Fiscale", "Documento");
         Card cc = new Card("PostePay", "Carta di credito");
         Denaro d = new Moneta(2);
         Denaro d2 = new Banconota(50);
         portafoglio.aggiungiDenaro(d);
         portafoglio.aggiungiDenaro(d2);
         portafoglio.aggiungiCarta(cf);
         portafoglio.aggiungiCarta(cc);
         System.out.println(portafoglio.toString());
         PortafoglioSerializator.serialize(portafoglio);
     }
}
