/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Portafoglio;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import exception.CartaGiaPresenteException;
import exception.CartaNonPresenteException;
import exception.DenaroNonPresenteException;
import exception.ImportoNegativoException;
import exception.ImportoNonPrelevabileException;


/**
 *
 * @author fabiano
 */
public class Portafoglio implements Serializable{
    private ArrayList<Card> carte;
    private ArrayList<Denaro> money;
    

    public Portafoglio() {
        this.money = new ArrayList<Denaro>();
        this.carte = new ArrayList<Card>();
    }

    public ArrayList<Card> getCarte() {
        return carte;
    }

    public void setCarte(ArrayList<Card> carte) {
        this.carte = carte;
    }

    public void aggiungiCarta(Card c) throws CartaGiaPresenteException{
    	if (carte.contains(c)) {
    		throw new CartaGiaPresenteException();
    	}
        carte.add(c);
    }
    
    public void rimuoviCarta(Card c) throws CartaNonPresenteException{
    	if (!carte.contains(c)) {
    		throw new CartaNonPresenteException();
    	}
        carte.remove(c);
    }
    
    public void aggiungiDenaro(Denaro d) throws ImportoNegativoException{
    	if (d.getValue() < 0) {
    		throw new ImportoNegativoException();
    	}
        money.add(d);
    }
    
    public void prelevaDenaro(Denaro d) throws ImportoNonPrelevabileException, DenaroNonPresenteException{
    	if (!money.contains(d)) {
    		throw new DenaroNonPresenteException();
    	}
    	if (d.getValue() > getImporto()) {
    		throw new  ImportoNonPrelevabileException();
    	}
        money.remove(d);
    }
    
    public List<Denaro> getDenaro(){
    	return money;
    }
    
    public double getImporto(){
        double importo = 0;
        for (Denaro d : money){
            importo += d.getValue();
        }
        return importo;
    }
    
    @Override
    public String toString() {
        return "Portafoglio{" + "carte=" + carte + ", money=" + money + '}';
    }
    
}