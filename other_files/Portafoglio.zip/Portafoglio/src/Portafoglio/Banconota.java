/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Portafoglio;

/**
 *
 * @author fabiano
 */
public class Banconota extends Denaro{
    
    public Banconota(double value) {
        super(value);
    }
    
    @Override
    public String toString() {
        return "Banconota{" + "value=" + getValue() + '}';
    }
    
}
