/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Portafoglio;

import java.io.Serializable;

/**
 *
 * @author fabiano
 */
public abstract class Denaro implements Serializable{
    private double value;

    public Denaro(double value) {
        this.value = value;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "Denaro{" + "value=" + value + '}';
    }

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return this.value == ((Denaro)obj).getValue();
	}
      
    
    
}
