package Portafoglio.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import Portafoglio.Card;
import Portafoglio.Portafoglio;
import Portafoglio.PortafoglioSerializator;
import exception.CartaGiaPresenteException;
import exception.CartaNonPresenteException;

public class MainPanel extends JPanel{
	
	public MainPanel(JFrame parent, Portafoglio portafoglio) {

		super();
		this.setOpaque(false);

		
		this.setLayout(new GridLayout(2, 1));
		JPanel panel = new JPanel();
		// panel.setOpaque(false);
		panel.setLayout(new BorderLayout());
		JLabel saldo = new JLabel(portafoglio.getImporto() + "€");
		saldo.setFont(new Font("Arial", 100, 100));
		panel.setAlignmentX(CENTER_ALIGNMENT);
		panel.add(saldo, BorderLayout.CENTER);
		panel.setBackground(Color.yellow);
		this.add(panel);
		this.setAlignmentX(CENTER_ALIGNMENT);
		JButton button1 = new JButton("Visualizza Carte");
		panel = new JPanel();
		panel.add(button1);
		button1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				parent.setContentPane(new VisualizzaCartePanel(parent,portafoglio));
				parent.revalidate();
			}
		});
		JButton button2 = new JButton("Visualizza Denaro");
		button2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				parent.setContentPane(new VisualizzaDenaroPanel(parent,portafoglio));
				parent.revalidate();

			}
		});
		panel.add(button2);

		JButton button3 = new JButton("Save");
		button3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				PortafoglioSerializator.serialize(portafoglio);
				JOptionPane.showMessageDialog(parent, "Saved!");
			}
		});
		panel.add(button3);
		this.add(panel);
	}

}
