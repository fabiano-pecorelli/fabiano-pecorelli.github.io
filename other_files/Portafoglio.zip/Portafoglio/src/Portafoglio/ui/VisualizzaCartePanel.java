package Portafoglio.ui;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import Portafoglio.Card;
import Portafoglio.Portafoglio;
import exception.CartaGiaPresenteException;
import exception.CartaNonPresenteException;

public class VisualizzaCartePanel extends JPanel{
	
	public VisualizzaCartePanel(JFrame parent, Portafoglio portafoglio) {

		super();
		this.setOpaque(true);
		this.setLayout(new GridLayout(2, 1));
		JPanel cartePanel = new JPanel();
		cartePanel.setLayout(new GridLayout(portafoglio.getCarte().size(), 1));
		for (Card c : portafoglio.getCarte()) {
			JPanel p = new JPanel();
			p.setLayout(new GridLayout(1,2));
			p.add(new JLabel(c.toString()));
			JButton b = new JButton("X");
			b.setBackground(Color.red);
			b.setOpaque(true);
			b.setBorderPainted(false);
			b.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					try{
						portafoglio.rimuoviCarta(c);
						parent.setContentPane(new VisualizzaCartePanel(parent, portafoglio));
						parent.revalidate();
					}
					catch(CartaNonPresenteException ex) {
						ex.printStackTrace();
					}
					
					
				}
			});
			p.setBackground(Color.yellow);
			p.add(b);
			cartePanel.add(p);
		}
		cartePanel.setBackground(Color.yellow);
		this.add(cartePanel);
		JButton button1 = new JButton("Go Back");
		JPanel panel = new JPanel();
		panel.add(button1);
		button1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				parent.setContentPane(new MainPanel(parent,portafoglio));
				parent.revalidate();
			}
		});
		JButton button2 = new JButton("Nuova Carta");
		button2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String nome = JOptionPane.showInputDialog(panel, "Nome");
				String tipo = JOptionPane.showInputDialog(panel, "Tipo");
				Card c = new Card(nome, tipo);
				try {
					portafoglio.aggiungiCarta(c);
				} catch (CartaGiaPresenteException ex) {
					JOptionPane.showMessageDialog(panel, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
				parent.setContentPane(new VisualizzaCartePanel(parent, portafoglio));
				parent.revalidate();
			}
		});
		panel.add(button2);
		this.add(panel);
	}

}
