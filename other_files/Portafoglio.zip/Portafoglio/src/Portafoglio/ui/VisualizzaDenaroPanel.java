package Portafoglio.ui;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import Portafoglio.Banconota;
import Portafoglio.Card;
import Portafoglio.Denaro;
import Portafoglio.Moneta;
import Portafoglio.Portafoglio;
import exception.CartaGiaPresenteException;
import exception.CartaNonPresenteException;
import exception.ImportoNegativoException;

public class VisualizzaDenaroPanel extends JPanel{
	
	public VisualizzaDenaroPanel(JFrame parent, Portafoglio portafoglio) {

		super();
		this.setOpaque(true);
		this.setLayout(new GridLayout(2, 1));
		JPanel denaroPanel = new JPanel();
		denaroPanel.setLayout(new GridLayout(1, 2));
		JPanel banconotePanel = new JPanel();
		JPanel monetePanel = new JPanel();
		int monete = 0;
		int banconote = 0;
		for (Denaro d : portafoglio.getDenaro()) {
			if (d instanceof Moneta) {
				monete++;
			} else if (d instanceof Banconota) {
				banconote++;
			}
		}
		banconotePanel.setLayout(new GridLayout(banconote, 1));
		monetePanel.setLayout(new GridLayout(monete, 1));
		for (Denaro d : portafoglio.getDenaro()) {
			if (d instanceof Moneta) {
				monetePanel.add(new JLabel(d.toString()));
			} else if (d instanceof Banconota) {
				banconotePanel.add(new JLabel(d.toString()));
			}
		}
		banconotePanel.setBackground(Color.yellow);
		monetePanel.setBackground(Color.yellow);
		denaroPanel.add(banconotePanel);
		denaroPanel.add(monetePanel);
		this.add(denaroPanel);
		JButton button1 = new JButton("Go Back");
		JPanel panel = new JPanel();
		panel.add(button1);
		button1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				parent.setContentPane(new MainPanel(parent,portafoglio));
				parent.revalidate();
			}
		});
		JButton button2 = new JButton("Nuova Banconota");
		button2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				double value = Double.parseDouble(JOptionPane.showInputDialog(panel, "Valore"));
				Banconota b = new Banconota(value);
				try {
					portafoglio.aggiungiDenaro(b);
				} catch (ImportoNegativoException ex) {
					JOptionPane.showMessageDialog(panel, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
				parent.setContentPane(new VisualizzaDenaroPanel(parent, portafoglio));
				parent.revalidate();
			}
		});
		panel.add(button2);
		JButton button3 = new JButton("Nuova Moneta");
		button3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				double value = Double.parseDouble(JOptionPane.showInputDialog(panel, "Valore"));
				Moneta b = new Moneta(value);
				try {
					portafoglio.aggiungiDenaro(b);
				} catch (ImportoNegativoException ex) {
					JOptionPane.showMessageDialog(panel, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
				parent.setContentPane(new VisualizzaDenaroPanel(parent, portafoglio));
				parent.revalidate();
			}
		});
		panel.add(button3);
		this.add(panel);
	}

}
