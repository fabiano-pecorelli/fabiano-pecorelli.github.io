/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Portafoglio.ui;

import Portafoglio.Portafoglio;
import Portafoglio.PortafoglioSerializator;
import java.awt.Toolkit;
import java.io.IOException;
import javax.swing.JFrame;

/**
 *
 * @author fabiano
 */
public class MainFrame extends JFrame {
	private Portafoglio portafoglio;

	public MainFrame() throws ClassNotFoundException, IOException {
		super();
		portafoglio = (Portafoglio) PortafoglioSerializator.deserialize();

		int screenSizeWidth = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		int screenSizeHeight = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();

		setBounds((screenSizeWidth - 950) / 2, (screenSizeHeight - 700) / 2, 950, 700);

		setContentPane(new MainPanel(this,portafoglio));
	}

}
