/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Portafoglio;

import java.io.Serializable;

/**
 *
 * @author fabiano
 */
public class Card implements Serializable{
    private String nome;
    private String tipo;

    public Card(String nome, String tipo) {
        this.nome = nome;
        this.tipo = tipo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Card{" + "nome=" + nome + ", tipo=" + tipo + '}';
    }
    
    @Override
    public boolean equals(Object c2) {
    	return this.getNome().equals(((Card) c2).getNome());
    }
    
    
}
